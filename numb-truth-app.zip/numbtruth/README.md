# NUMB TRUTH — AI Community Platform
### Built for Vincenzo' | Truth Is Uncomfortable

## QUICK START

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your API key
```bash
# Linux / Mac
export ANTHROPIC_API_KEY=sk-ant-api03-YOUR-KEY-HERE

# Windows CMD
set ANTHROPIC_API_KEY=sk-ant-api03-YOUR-KEY-HERE

# Windows PowerShell
$env:ANTHROPIC_API_KEY="sk-ant-api03-YOUR-KEY-HERE"
```

### 3. Run the server
```bash
python app.py
```

### 4. Open in browser
```
http://localhost:5000
```

---

## DEPLOY TO THE INTERNET (FREE OPTIONS)

### Option A — Railway (Recommended, 1 click)
1. Go to railway.app
2. New Project → Deploy from GitHub
3. Upload this folder
4. Set ANTHROPIC_API_KEY in Variables
5. Done — get a public URL instantly

### Option B — Render.com (Free tier)
1. Go to render.com → New Web Service
2. Connect GitHub repo with this code
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Set ANTHROPIC_API_KEY in Environment Variables
6. Deploy — public URL in minutes

### Option C — Heroku
1. heroku create numb-truth-ai
2. heroku config:set ANTHROPIC_API_KEY=your-key
3. git push heroku main

### Option D — VPS (DigitalOcean / Linode)
```bash
# Install nginx + run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

---

## FEATURES
- Holographic 4D animated UI
- Black & Gold Numb Truth branding
- AI with deep philosophical reasoning
- Real-time web search
- Voice input + voice output
- Mobile responsive
- No API key exposed to users
- Server-side all AI calls

## VINCENZO' SIGNATURE
Built by the Numb Truth team.
Truth Is Uncomfortable.
